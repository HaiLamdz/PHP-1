<?php
class dashboardController{
    function dashboard(){
        require_once 'views/dashboard.php';
    }
}
?>